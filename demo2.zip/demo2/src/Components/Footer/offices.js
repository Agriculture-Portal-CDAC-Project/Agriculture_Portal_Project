import React from 'react'

const offices = () => {
  return (
    <div>offices</div>
  )
}

export default offices