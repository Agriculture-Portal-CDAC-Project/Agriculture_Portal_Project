// Company.js
import React from 'react';

const Company = () => {
  return (
    <div style={{ textAlign: 'center' }}>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>

      <h1>Company Page Work in progress</h1>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
      <br/>
    </div>
  );
}

export default Company;
