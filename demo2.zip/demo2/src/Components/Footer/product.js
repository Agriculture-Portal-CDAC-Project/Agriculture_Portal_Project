import React from 'react'

const product = () => {
  return (
    <div>product</div>
  )
}

export default product