import p1_img from './product_1.png'
import p2_img from './product_2.png'
import p3_img from './product_3.png'
import p4_img from './product_41.png'
import p5_img from './product_4.png'
import p6_img from './product_61.png'
import p7_img from './product_71.png'
import p8_img from './product_81.png'
import p9_img from './product_91.png'


let data_product = [
  {
    id: 1,
    name: "TrustBasket Organic Vermicompost Fertilizer Manure For Plants 5 Kg Green",
    image: p1_img,
    new_price: 309,
    old_price: 499,
  },
  {id:2,
    name:"TrustBasket Epsom Salt (1 KG) for Plant Growth & Development |Contains Magnesium Sulfur | Water Soluble Plant Fertilizer",
    image:p2_img,
    new_price:185,
    old_price:341,
  },
  {id:3,
    name:"Ugaoo Vermicompost for Plants 1 Kg - Organic Fertilizer & Manure",
    image:p3_img,
    new_price:179,
    old_price:245,
  },
  {id:4,
    name:"Ugaoo Vermicompost for Plants 1 Kg - Organic Fertilizer & Manure",
    image:p5_img,
    new_price:179,
    old_price:245,
  }
  //{id:4,
  //   name:"Spinach",
  //   image:p4_img,
  //   new_price:15,
  //   old_price:20,
  // },
  // {id:5,
  //   name:"Coriander",
  //   image:p5_img,
  //   new_price:45,
  //   old_price:60,
  // },
  // {id:6,
  //   name:"cabbage",
  //   image:p6_img,
  //   new_price:30 ,
  //   old_price:50,
  // },
  // {id:7,
  //   name:"Valencia Orange 5 pieces (800 g - 1000 g)",
  //   image:p7_img,
  //   new_price:150,
  //   old_price:200,
  // },
  // {id:8,
  //   name:"Washington Apple 2 pieces (250 g - 350 g)",
  //   image:p8_img,
  //   new_price:100,
  //   old_price:150,
  // },
  // {id:9,
  //   name:"Strawberry",
  //   image:p9_img,
  //   new_price:60 ,
  //   old_price:100,
  // },
  
];

export default data_product;
