const express = require('express')
const router = express.Router()
// const mysql = require('mysql2/promise')
const dbPromise = require('../dbPromise')
///const db = require('../db')
const utils = require('../utils')
const config = require('config')

// const dbPromise = mysql.createConnection({
//     host : config.get("host"),
//     user : config.get("user"),
//     password : config.get("password"),
//     database : config.get("database")
// })


router.post('/:id', async (request, response) => {
    var u_id = request.params.id;
  // step 1: get all items from cart
  const [items] = await dbPromise.query(`select * from cart where u_id = ${u_id}`);
//   console.log(items)

  // step 2: insert the order record in orderId and capture the orderId
  let total = 0
  for (const item of items) {
    total += item['total']
  }
  const [row] = await dbPromise.execute(
    `
    insert into orderStatus
        (u_id, total)
    values
        (?, ?)
  `,
    [u_id, total]
  )
  // capture order Id
  const orderId = row['insertId']

  // step 3: insert the order details in orderDetails table with orderId
  for (const item of items) {
    await dbPromise.execute(
      `
        insert into orderDetails
            (order_id, p_id, quantity, price, total)
        values
            (?, ?, ?, ?, ?)
    `,
      [
        orderId,
        item['p_id'],
        item['qty'],
        item['price'],
        item['total'],
      ]
    )
  }

  // step 4: clear the cart for the user
  await dbPromise.execute(`delete from cart where u_id = ?`, [
           u_id
  ])
  
  const result = {
    status : "success"
  }
  // response.write(JSON.stringify("done"));
  // response.end();
  //console.log(response.send("donnne"))
   response.send(result);
 
})

// router.get('/getOrder/:id', async (request, response) => {
//   const statement = `
//         select 
//             id, total, createdTimestamp 
//         from
//             orderStatus
//         where
//             u_id = ?
//     `
//   const [orders] = await dbPromise.query(statement, [request.params.id])
//   for (const order of orders) {
//     const [details] = await dbPromise.query(
//       `select * from orderDetails where order_id = ?`,
  //     [order['id']]
  //   )
  //   order['details'] = details
  // }

//   response.send(utils.createResult(er))
// })


// router.get('/getOrder/:id', (request, response) => {
//   const { id } = request.params
//   const statement = "select * from orderDetails where order_id=?"
//   const values = [ id ]
//   dbPromise.query(statement,values,(err,result)=>{
//     res.send(utils.createResult(err,result));
// });

// })



module.exports = router