const mysql= require('mysql');
const express = require('express');
const config = require('config');
const utils =require('../utils');
const crypto = require('crypto-js');
const jwt = require('jsonwebtoken'); // jsonWebToken for login validation 
const key = config.get("key");
const app = express.Router();

// const connectionDetails = {
//     host : config.get("host"),
//     database : config.get("database"),
//     password : config.get("password"),
//     user : config.get("user")
// }


const db = mysql.createConnection({
    host : config.get("host"),
    user : config.get("user"),
    password : config.get("password"),
    database : config.get("database")
})
// user registration 
app.post("/register",(request,response)=>
{ 
    console.log("inside register")
    var first_name = request.body.first_name;
    var last_name = request.body.last_name;
    var email = request.body.email;
    var password = request.body.password;
    var mobile = request.body.mobile;
    var dob = request.body.dob;
    var address = request.body.address;
    // var roll = request.body.roll;

    var encryptedPassword = String(crypto.SHA256(password));
    console.log(encryptedPassword);

    const statement =`insert into users(first_name, last_name, email, password, mobile,dob, address, roll) values('${first_name}','${last_name}','${email}','${encryptedPassword}','${mobile}','${dob}','${address}','USER')`;
     
     db.query(statement,(error , result)=>{
            response.send(utils.createResult(error,result));
     })

});





//user login
app.post("/login",(request, response)=>{
    var email = request.body.email;
    var password = request.body.password;
    var encryptedPassword = String(crypto.SHA256(password));
    

    const statement = `select * from users where email = '${email}' && password = '${encryptedPassword}'`;

    db.query(statement,(error, result)=>
    {
        if(error==null)
        {
            //response.send(utils.createResult(error,result));
            if(result.length!=0)
           {
            var payload ={
                          "user_credentials" :result,
                          "createdat" : "05022024"
                         }
            
            var token = jwt.sign(payload,key);
            console.log(token);
            //console.log(result.RowDataPacket.roll);
            // if(result.data.roll==="ADMIN")
            // {
            //     var responseMessage ={
            //         status : "success",
            //         data : result,
            //         token :token,
            //         roll : "ADMIN"
            //       //   result : result
            //                   }
            //     response.send(responseMessage)
            // }
            // else{
                var responseMessage ={
                    status : "success",
                    data : result,
                    token :token
                  //   result : result
                              }
                response.send(responseMessage)              
        //   response.write(JSON.stringify(responseMessage));
                  
        //   response.end();
            // }
           
           
           }
           else
           {
              response.send(utils.createResult(error,result));  
           }
           
        }
        else{
           console.log(error);
           response.send(utils.createResult(error,result));
        }
    })
   
})

// get all users
app.get("/",(request, response)=>{
    const statement =`select * from users `;    
    db.query(statement,(error , result)=>{
         response.send(utils.createResult(error,result));      
    })
})

// change password 

app.put("/changePassword", (request,response)=>
{

    
    const {password,id} = request.body;
    console.log(password + "pass");
    console.log("id change "+id);

    var encryptedPassword = String(crypto.SHA256(password));
    const query = "update users set password = ? where id = ?";
    const values = [encryptedPassword, id];
    db.query(query,values,(error,result)=>
    {
        response.send(utils.createResult(error,result));
    })
})


app.put("/editProfile",(request,response)=>
{ 
    console.log("inside edit profile")
    const {id,first_name,last_name,email,mobile,dob,address}=request.body;

  
    // var roll = request.body.roll;
    console.log(" id "+ email);
    const query =`update users set first_name=?,last_name=?,email=?,mobile=?,address=? where id =?`;
    const values = [first_name,last_name,email,mobile,address,id]
     
    db.query(query,values,(err,result)=>{
        console.log("query is : "+query);
        response.send(utils.createResult(err,result));
    })

});

app.get("/:id",(request, response)=>{
    const {id} = request.params;
    const query =`select * from users where id=? `;  
    const values = [id];
    
    db.query(query,values,(err,result)=>{

        response.send(utils.createResult(err,result));
    })
})



module.exports = app;
