
const express = require('express');
const config = require('config');
const cors = require("cors");
const jwt = require('jsonwebtoken');
const key = config.get("key");
const PORT = config.get("port");



const app = express()


const productHandlerApp = require('./routes/product');
const categoryHandlerApp = require('./routes/category');
const cartHandlerApp = require('./routes/cart');
const userHandlerApp = require('./routes/users');
const orderHandlerApp = require('./routes/orders')


app.use(cors("*"))
app.use(express.json())

// app.use((request ,response,next)=>
// {
//     console.log(request.url);
//     if(request.url!= '/users/login' && request.url!='/users/register')
//     {
//         if(request.headers.authorization != undefined || request.header.authorization != null)
//         {
//             console.log("authorization header recieved is :" + request.headers.authorization);
//             var headerContents = request.headers.authorization.split(" ");
//             var tokenReceived  = headerContents[1];
//             console.log(tokenReceived);
//             var payloadDecodeFromToken = jwt.verify(tokenReceived,key);
//             if(payloadDecodeFromToken.createdat == "05022024")
//             {
//                 console.log(payloadDecodeFromToken.createdat);
//                 next();
//             }
//             else{
//                 response.send("invalid token");
//             }
           
//         }
//         else{
//             response.send("token needed!!");
//         }
//     }
//     else{
//         next();
//     }
// })



app.use("/product", productHandlerApp);
app.use("/category",categoryHandlerApp);
app.use("/cart",cartHandlerApp);
app.use("/users",userHandlerApp);
app.use("/order",orderHandlerApp );

app.listen(PORT, ()=>{console.log(`server started listening at port ${PORT}`);});