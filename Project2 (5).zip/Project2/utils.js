function createResult(error,result) {
    var data = {}
    if (error) {
      data["status"] = "error"
      data["error"] = error
    } else {
      data["status"] = "success"
      data["data"] = result
    }
    return data
  }
  
  module.exports = { createResult }


  // function createResult(error, data) {
  //   var result = {}
  //   if (error) {
  //     result["status"] = "error"
  //     result["error"] = error
  //   } else {
  //     result["status"] = "success"
  //     result["data"] = data
  //   }
  //   return result
  // }
  
  // module.exports = { createResult }